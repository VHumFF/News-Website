"use client"

import Register from "../pages/Register"

export default function SyntheticV0PageForDeployment() {
  return <Register />
}